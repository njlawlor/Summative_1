#include <conio.h>
#include "test.h"

int main(){
	int firstNumber = 5;
	int secondNumber = 10;
	
	TestAddTwoNumber(firstNumber, secondNumber);
	TestSubtractTwoNumber(firstNumber, secondNumber);

	_getch();
	return 0;
}