#ifndef _TEST_H__
#define _TEST_H__

#include <iostream>

void TestAddTwoNumber(int, int);
void TestSubtractTwoNumber(int, int);

#endif