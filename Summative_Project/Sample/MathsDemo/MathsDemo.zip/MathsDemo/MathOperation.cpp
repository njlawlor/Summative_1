#include "MathOperation.h"

int AddTwoNumber(int x, int y){
	int z = x + y;
	return z;
}


int SubtractTwoNumber(int x, int y){
	int z = x - y;
	return z;
}