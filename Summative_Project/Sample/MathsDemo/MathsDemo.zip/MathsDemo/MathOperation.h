#ifndef _MATHOPERATION_H__
#define _MATHOPERATION_H__

int AddTwoNumber(int x, int y);
int SubtractTwoNumber(int x, int y);

#endif